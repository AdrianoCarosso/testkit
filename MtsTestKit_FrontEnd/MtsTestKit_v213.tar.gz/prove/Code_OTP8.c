 //Header Files
#include<stdio.h> //printf
#include<string.h>    //strlen
#include<stdlib.h>    //malloc
//#include<sys/socket.h>    //you know what this is for
//#include<arpa/inet.h> //inet_addr , inet_ntoa , ntohs etc
//#include<netinet/in.h>
#include<unistd.h>    //getpid
 
#include <time.h>
#include <sys/types.h>
#include <sys/timeb.h>
#include <sys/stat.h>
//#include <sys/timeb.h>
#include <linux/if.h>

  /// <summary>
  /// Restituisce una One Time Password per sbloccare un mezzo
  /// </summary>
  /// <remarks>
  /// Author and creation date:
  ///    Paolo Carminati - 19/03/2013
  /// Updater: 
  ///    
  /// </remarks>
  /// <param name="Mezzo"></param>
  /// <returns></returns>
// 12345678
// 303602643 
int main( int argc , char *argv[])
{
unsigned int intCodiceHW, intDataOra, code, ii ;
int i = 0, j = 0;
char buffer[20], buffer1[20] ;
//struct timeb ltime;
time_t ltime;
struct tm ldate ;

	if (argc<2) {
		printf("Usage: %s <codicehw> [data-ora (ddMMHHmm)]\n", argv[0]);
		exit(1) ;
	}

	//reverse hwcode	
	j = strlen(argv[1]) ;
	for(i=0;i<8;i++){
		buffer1[i] = argv[1][j-1-i] ;
	}
	buffer1[8] = '\0';
	
	intCodiceHW = atol(buffer1) ;
	sprintf(argv[1], "%u", intCodiceHW) ;
	// prendo le ultime 8 cifre numeriche del codice hw
	// se meno di 8 cifre aggiungo in testa "87654321"
	strcpy(buffer, "87654321") ;
	j = strlen(argv[1]) ;
	if (j>7)
	 i = 8 ;
	else
	 i = j ;
	printf("replace <%s> with <%s>\n", &buffer[(8-i)], &argv[1][(j-i)] ) ;
	
	strcpy(&buffer[(8-i)], &argv[1][(j-i)] ) ;
//	for (i = Mezzo.CommunicationDevice.HwCode.Length - 1; i >= 0; i--) {
//	    if (char.IsDigit(Mezzo.CommunicationDevice.HwCode[i])) {
//	       partialCode.Insert(0, Mezzo.CommunicationDevice.HwCode[i]);
//	       if (++j >= 8)
//	          break;
//	    }
//	 }

	// leggo la parte numerica del codice HW come int
	intCodiceHW = atol(buffer) ;
	printf("decoded %u %u\n", intCodiceHW, (intCodiceHW/7) ) ;
	
//         if (!int.TryParse(partialCode.ToString(), out intCodiceHW)) {
//            intCodiceHW = 12345678;
//         }
	// prendo la data ed ora del momento (giorno,mese,ora,minuti)
	i = 0 ;
	if (argc<3) 
		i = 1 ;
	else if (strlen(argv[2])!=8)
		i = 1 ;
	
	if (i){
		time(&ltime);
		localtime_r( &ltime, &ldate ) ;
		//sprintf(buffer, "%02d%02d%02d%02d", ldate.tm_mday, (ldate.tm_mon+1), ldate.tm_hour, ldate.tm_min) ;
		sprintf(buffer, "%02d%02d%02d%02d", ldate.tm_mday, (ldate.tm_mon+1), ldate.tm_hour, (ldate.tm_yday/4)) ;
	}else
		strcpy(buffer, argv[2]) ;
		
	printf("datetime is <%s>\n", buffer ) ;
	
	
//         string dataOra = DateTime.Now.ToString("ddMMHHmm");
    // mescolo la data
    buffer1[0] = buffer[7] ;
    buffer1[1] = buffer[5] ;
    buffer1[2] = buffer[6] ;
    buffer1[3] = buffer[4] ;
    buffer1[4] = buffer[3] ;
    buffer1[5] = buffer[0] ;
    buffer1[6] = buffer[1] ;
    buffer1[7] = buffer[6] ;
    buffer1[8] = '\0' ;
//         string dataCript =
//            string.Format("{0}{1}{2}{3}{4}{5}{6}{7}", dataOra[7], dataOra[5], dataOra[2], dataOra[4], dataOra[3], dataOra[0], dataOra[1], dataOra[6]);
//         // la leggo come int
//         if (!int.TryParse(dataCript, out intDataOra)) {
//            intDataOra = 23011215;
//         }
	intDataOra = atol(buffer1) ;
	
	// la xorro col codice hardware
//         int code = intDataOra ^ intCodiceHW;
	code = intDataOra ^ intCodiceHW;
//         ObjEventType eventType = new ObjEventType(EventType.IncomingContextMessage);
//         string description = string.Format("{0}: {1}: [{2}]",
//            EnumUtils.GetDescription(EventCodeContextMessage.VehicleOTPGenerated), Mezzo.Name, code);
//
//         CreateNewEvent(Mezzo, User, eventType, (short)EventCodeContextMessage.VehicleOTPGenerated, description);

         // Restituisco il codice ottenuto come stringa
//         return code.ToString();
	printf("Code is <%08u>\n", code ) ;

         // Per la decodifica:
         //code = code ^ intCodiceHW;
         //string codeStr = code.ToString();
         //string codeDeCript = string.Format("{5}{6}{2}{4}{3}{1}{7}{0}", codeStr[0], codeStr[1], codeStr[2], codeStr[3], codeStr[4], codeStr[5], codeStr[6], codeStr[7]);
         //return codeDeCript;

         // // Per la decodicica in C (se non ho fatto errori...)
         //int optCode_Int, codeHW_Int;
         //int cryptedDatetime_Int;
         //char strCryptedDatetime[20];
         //char strDateTimeGeneration[20];

         //sscanf(OTPcode, "%ld", &optCode_Int);
         //sscanf(CodiceHW, "%ld", &codeHW_Int);
         //cryptedDatetime_Int = optCode_Int ^ codeHW_Int;
         //sprintf(strCryptedDatetime, "%ld", cryptedDatetime_Int);
         // // In strDateTimeGeneration ottengo la data di generazione nel formato: "ddMMHHmm"
         //sprintf(strDateTimeGeneration, "%c%c%c%c%c%c%c%c", 
         //strCryptedDatetime[5], strCryptedDatetime[6], strCryptedDatetime[2], strCryptedDatetime[4],
         //strCryptedDatetime[3], strCryptedDatetime[1], strCryptedDatetime[7], strCryptedDatetime[0]);
      }

