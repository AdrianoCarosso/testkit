/**
  * @file md5.c
  * @brief MD5 (Message-Digest Algorithm)
  *
  * @section License
  *
  * SPDX-License-Identifier: GPL-2.0-or-later
  *
  * Copyright (C) 2010-2021 Oryx Embedded SARL. All rights reserved.
  *
  * This file is part of CycloneCRYPTO Open.
  *
  * This program is free software; you can redistribute it and/or
  * modify it under the terms of the GNU General Public License
  * as published by the Free Software Foundation; either version 2
  * of the License, or (at your option) any later version.
  *
  * This program is distributed in the hope that it will be useful,
  * but WITHOUT ANY WARRANTY; without even the implied warranty of
  * MERCHANTABILITY or FITNESS FOR A PARTICULAR PURPOSE.  See the
  * GNU General Public License for more details.
  *
  * You should have received a copy of the GNU General Public License
  * along with this program; if not, write to the Free Software Foundation,
  * Inc., 51 Franklin Street, Fifth Floor, Boston, MA  02110-1301, USA.
  *
  * @section Description
  *
  * The MD5 algorithm takes as input a message of arbitrary length and produces
  * as output a 128-bit message digest of the input. Refer to RFC 1321
  *
  * @author Oryx Embedded SARL (www.oryx-embedded.com)
  * @version 2.0.2
  **/
  
#include <stdint.h>
#include <stdio.h>
#include <stdlib.h>
#include <string.h>

 /******************************************************/
// from md5.h
typedef struct
{
   union
   {
      uint32_t h[4];
      uint8_t digest[16];
   };
   union
   {
      uint32_t x[16];
      uint8_t buffer[64];
   };
   size_t size;
   uint64_t totalSize;
} Md5Context;
#define MD5_DIGEST_SIZE 16
  
 /******************************************************/
 // from crypto.h
#define ROL32(a, n) (((a) << (n)) | ((a) >> (32 - (n))))

//Swap a 32-bit integer
#define SWAPINT32(x) ( \
   (((uint32_t)(x) & 0x000000FFUL) << 24) | \
   (((uint32_t)(x) & 0x0000FF00UL) << 8) | \
   (((uint32_t)(x) & 0x00FF0000UL) >> 8) | \
   (((uint32_t)(x) & 0xFF000000UL) >> 24))

// 'htole32' non serve
 /******************************************************/
 //MD5 auxiliary functions
 #define MD5F(x, y, z) (((x) & (y)) | (~(x) & (z)))
 #define MD5G(x, y, z) (((x) & (z)) | ((y) & ~(z)))
 #define MD5H(x, y, z) ((x) ^ (y) ^ (z))
 #define MD5I(x, y, z) ((y) ^ ((x) | ~(z)))
  
 #define MD5FF(a, b, c, d, x, s, k) a += MD5F(b, c, d) + (x) + (k), a = ROL32(a, s) + (b)
 #define MD5GG(a, b, c, d, x, s, k) a += MD5G(b, c, d) + (x) + (k), a = ROL32(a, s) + (b)
 #define MD5HH(a, b, c, d, x, s, k) a += MD5H(b, c, d) + (x) + (k), a = ROL32(a, s) + (b)
 #define MD5II(a, b, c, d, x, s, k) a += MD5I(b, c, d) + (x) + (k), a = ROL32(a, s) + (b)
  
 //MD5 padding
 static const uint8_t padding[64] =
 {
    0x80, 0x00, 0x00, 0x00, 0x00, 0x00, 0x00, 0x00, 0x00, 0x00, 0x00, 0x00, 0x00, 0x00, 0x00, 0x00,
    0x00, 0x00, 0x00, 0x00, 0x00, 0x00, 0x00, 0x00, 0x00, 0x00, 0x00, 0x00, 0x00, 0x00, 0x00, 0x00,
    0x00, 0x00, 0x00, 0x00, 0x00, 0x00, 0x00, 0x00, 0x00, 0x00, 0x00, 0x00, 0x00, 0x00, 0x00, 0x00,
    0x00, 0x00, 0x00, 0x00, 0x00, 0x00, 0x00, 0x00, 0x00, 0x00, 0x00, 0x00, 0x00, 0x00, 0x00, 0x00
 };
  
 //MD5 constants
 static const uint32_t MD5k[64] =
 {
    0xD76AA478, 0xE8C7B756, 0x242070DB, 0xC1BDCEEE, 0xF57C0FAF, 0x4787C62A, 0xA8304613, 0xFD469501,
    0x698098D8, 0x8B44F7AF, 0xFFFF5BB1, 0x895CD7BE, 0x6B901122, 0xFD987193, 0xA679438E, 0x49B40821,
    0xF61E2562, 0xC040B340, 0x265E5A51, 0xE9B6C7AA, 0xD62F105D, 0x02441453, 0xD8A1E681, 0xE7D3FBC8,
    0x21E1CDE6, 0xC33707D6, 0xF4D50D87, 0x455A14ED, 0xA9E3E905, 0xFCEFA3F8, 0x676F02D9, 0x8D2A4C8A,
    0xFFFA3942, 0x8771F681, 0x6D9D6122, 0xFDE5380C, 0xA4BEEA44, 0x4BDECFA9, 0xF6BB4B60, 0xBEBFBC70,
    0x289B7EC6, 0xEAA127FA, 0xD4EF3085, 0x04881D05, 0xD9D4D039, 0xE6DB99E5, 0x1FA27CF8, 0xC4AC5665,
    0xF4292244, 0x432AFF97, 0xAB9423A7, 0xFC93A039, 0x655B59C3, 0x8F0CCC92, 0xFFEFF47D, 0x85845DD1,
    0x6FA87E4F, 0xFE2CE6E0, 0xA3014314, 0x4E0811A1, 0xF7537E82, 0xBD3AF235, 0x2AD7D2BB, 0xEB86D391
 };
  
 //MD5 object identifier (1.2.840.113549.2.5)
 const uint8_t md5Oid[8] = {0x2A, 0x86, 0x48, 0x86, 0xF7, 0x0D, 0x02, 0x05};
  
/******************************************************/

// @brief Process message in 16-word blocks
// @param[in] context Pointer to the MD5 context
  
void md5ProcessBlock(Md5Context *context)
{

	//Initialize the 4 working registers
	uint32_t a = context->h[0];
	uint32_t b = context->h[1];
	uint32_t c = context->h[2];
	uint32_t d = context->h[3];

	//Process message in 16-word blocks
	uint32_t *x = context->x;

	// PROVA
// 	//Convert from little-endian byte order to host byte order
// 	for(i = 0; i < 16; i++){
// 		printf("SW %08x %08lx\n", x[i], SWAPINT32(x[i]) ) ;
// 		x[i] = SWAPINT32(x[i]);
// 	}

	//Round 1
	MD5FF(a, b, c, d, x[0],  7,  MD5k[0]);
	MD5FF(d, a, b, c, x[1],  12, MD5k[1]);
	MD5FF(c, d, a, b, x[2],  17, MD5k[2]);
	MD5FF(b, c, d, a, x[3],  22, MD5k[3]);
	MD5FF(a, b, c, d, x[4],  7,  MD5k[4]);
	MD5FF(d, a, b, c, x[5],  12, MD5k[5]);
	MD5FF(c, d, a, b, x[6],  17, MD5k[6]);
	MD5FF(b, c, d, a, x[7],  22, MD5k[7]);
	MD5FF(a, b, c, d, x[8],  7,  MD5k[8]);
	MD5FF(d, a, b, c, x[9],  12, MD5k[9]);
	MD5FF(c, d, a, b, x[10], 17, MD5k[10]);
	MD5FF(b, c, d, a, x[11], 22, MD5k[11]);
	MD5FF(a, b, c, d, x[12], 7,  MD5k[12]);
	MD5FF(d, a, b, c, x[13], 12, MD5k[13]);
	MD5FF(c, d, a, b, x[14], 17, MD5k[14]);
	MD5FF(b, c, d, a, x[15], 22, MD5k[15]);

	//Round 2
	MD5GG(a, b, c, d, x[1],  5,  MD5k[16]);
	MD5GG(d, a, b, c, x[6],  9,  MD5k[17]);
	MD5GG(c, d, a, b, x[11], 14, MD5k[18]);
	MD5GG(b, c, d, a, x[0],  20, MD5k[19]);
	MD5GG(a, b, c, d, x[5],  5,  MD5k[20]);
	MD5GG(d, a, b, c, x[10], 9,  MD5k[21]);
	MD5GG(c, d, a, b, x[15], 14, MD5k[22]);
	MD5GG(b, c, d, a, x[4],  20, MD5k[23]);
	MD5GG(a, b, c, d, x[9],  5,  MD5k[24]);
	MD5GG(d, a, b, c, x[14], 9,  MD5k[25]);
	MD5GG(c, d, a, b, x[3],  14, MD5k[26]);
	MD5GG(b, c, d, a, x[8],  20, MD5k[27]);
	MD5GG(a, b, c, d, x[13], 5,  MD5k[28]);
	MD5GG(d, a, b, c, x[2],  9,  MD5k[29]);
	MD5GG(c, d, a, b, x[7],  14, MD5k[30]);
	MD5GG(b, c, d, a, x[12], 20, MD5k[31]);

	//Round 3
	MD5HH(a, b, c, d, x[5],  4,  MD5k[32]);
	MD5HH(d, a, b, c, x[8],  11, MD5k[33]);
	MD5HH(c, d, a, b, x[11], 16, MD5k[34]);
	MD5HH(b, c, d, a, x[14], 23, MD5k[35]);
	MD5HH(a, b, c, d, x[1],  4,  MD5k[36]);
	MD5HH(d, a, b, c, x[4],  11, MD5k[37]);
	MD5HH(c, d, a, b, x[7],  16, MD5k[38]);
	MD5HH(b, c, d, a, x[10], 23, MD5k[39]);
	MD5HH(a, b, c, d, x[13], 4,  MD5k[40]);
	MD5HH(d, a, b, c, x[0],  11, MD5k[41]);
	MD5HH(c, d, a, b, x[3],  16, MD5k[42]);
	MD5HH(b, c, d, a, x[6],  23, MD5k[43]);
	MD5HH(a, b, c, d, x[9],  4,  MD5k[44]);
	MD5HH(d, a, b, c, x[12], 11, MD5k[45]);
	MD5HH(c, d, a, b, x[15], 16, MD5k[46]);
	MD5HH(b, c, d, a, x[2],  23, MD5k[47]);

	//Round 4
	MD5II(a, b, c, d, x[0],  6,  MD5k[48]);
	MD5II(d, a, b, c, x[7],  10, MD5k[49]);
	MD5II(c, d, a, b, x[14], 15, MD5k[50]);
	MD5II(b, c, d, a, x[5],  21, MD5k[51]);
	MD5II(a, b, c, d, x[12], 6,  MD5k[52]);
	MD5II(d, a, b, c, x[3],  10, MD5k[53]);
	MD5II(c, d, a, b, x[10], 15, MD5k[54]);
	MD5II(b, c, d, a, x[1],  21, MD5k[55]);
	MD5II(a, b, c, d, x[8],  6,  MD5k[56]);
	MD5II(d, a, b, c, x[15], 10, MD5k[57]);
	MD5II(c, d, a, b, x[6],  15, MD5k[58]);
	MD5II(b, c, d, a, x[13], 21, MD5k[59]);
	MD5II(a, b, c, d, x[4],  6,  MD5k[60]);
	MD5II(d, a, b, c, x[11], 10, MD5k[61]);
	MD5II(c, d, a, b, x[2],  15, MD5k[62]);
	MD5II(b, c, d, a, x[9],  21, MD5k[63]);

	//Update the hash value
	context->h[0] += a;
	context->h[1] += b;
	context->h[2] += c;
	context->h[3] += d;
}
    
// @brief Initialize MD5 message digest context
// @param[in] context Pointer to the MD5 context to initialize
  
void md5Init(Md5Context *context)
{
	//Set initial hash value
	context->h[0] = 0x67452301;
	context->h[1] = 0xEFCDAB89;
	context->h[2] = 0x98BADCFE;
	context->h[3] = 0x10325476;

	//Number of bytes in the buffer
	context->size = 0;
	//Total length of the message
	context->totalSize = 0;
 }
  
  
// @brief Update the MD5 context with a portion of the message being hashed
// @param[in] context Pointer to the MD5 context
// @param[in] data Pointer to the buffer being hashed
// @param[in] length Length of the buffer
  
void md5Update(Md5Context *context, const void *data, size_t length)
{
size_t n;
  
	//Process the incoming data
	while(length > 0){
		//The buffer can hold at most 64 bytes
		n = MIN(length, 64 - context->size);

		//Copy the data to the buffer
		memcpy(context->buffer + context->size, data, n);

		//Update the MD5 context
		context->size += n;
		context->totalSize += n;
		//Advance the data pointer
		data = (uint8_t *) data + n;
		//Remaining bytes to process
		length -= n;

		//Process message in 16-word blocks
		if(context->size == 64){
			//Transform the 16-word block
			md5ProcessBlock(context);
			//Empty the buffer
			context->size = 0;
		}
	}
}
  
  

// @brief Finish the MD5 message digest
// @param[in] context Pointer to the MD5 context
// @param[out] digest Calculated digest (optional parameter)

  
void md5Final(Md5Context *context, uint8_t *digest)
{
size_t paddingSize;
uint64_t totalSize;
  
	//Length of the original message (before padding)
	totalSize = context->totalSize * 8;

	//Pad the message so that its length is congruent to 56 modulo 64
	if(context->size < 56){
		paddingSize = 56 - context->size;
	}else{
		paddingSize = 64 + 56 - context->size;
	}

	//Append padding
	md5Update(context, padding, paddingSize);

	//Append the length of the original message
	// 'htole32' non serve
// 	context->x[14] = htole32((uint32_t) totalSize);
// 	context->x[15] = htole32((uint32_t) (totalSize >> 32));
	context->x[14] = ((uint32_t) totalSize);
	context->x[15] = ((uint32_t) (totalSize >> 32));

	//Calculate the message digest
	md5ProcessBlock(context);

	//PROVA
// 	//Convert from host byte order to little-endian byte order
// 	for(i = 0; i < 4; i++){
// 		printf("a:%x b:%x\n", context->h[i], htole32(context->h[i]) );
// 		context->h[i] = htole32(context->h[i]);
// 	}

	//Copy the resulting digest
	if(digest != NULL){
		memcpy(digest, context->digest, MD5_DIGEST_SIZE);
	}

}
  
  
