
#define MIN(A,B) (((A)<(B))?(A):(B))

#include "chap_md5.h"
#include "randm.h"

int main(void)
{
	printf("Random: %d\n", avRandom());	
}

