// pseudo_random.c

#include <stdlib.h> // rand(), srand()
#include <stdio.h>  // printf()

// Genera una sequenza di n numeri pseudo-random di 5 cifre.
void PrngSequence(int n)
{
	int range_min = 10000;
	int range_max = 99999;
	
    for (int i = 0; i < n; i++)
    {
        int r = ((double)rand() / RAND_MAX) * (range_max - range_min) + range_min;
        printf("  %6d\n", r);
    }
}

int main(void)
{
    // Il programma deve ricevere un codice a 6 cifre, ad esempio 198342
	// La prima cifra identifica l'azione richiesta, nello specifico: 
	//        1=apertura CCS, 2=chiusura CCS, 3=apertura Manutenzione, 4=chiusura Manutenzione, 8=apertura PSP, 9=chiusura PSP
    // Il numero restante a 5 cifre (PRNG) dovr� essere ricercato nella sequenza generata dal metodo PrngSequence
	// ----------------------------
	// In PrngSequence, la sequenza deve essere generata tramite un seed, creato in base al seguente algoritmo:
	// SEED = codiceHW + AAMMGGHH + Action
	//    codiceHW = Codice Hardware del dispositivo (IMEI ?)
	//    AAMMGGHH = numero relativo alla data/ora (UTC) nel formato AAMMGGHH(*)
	//    Action   = Azione richiesta (ricavata dalla prima cifra del codice ricevuto)
	//
	// (*) Per le operazioni di Passepartout (PSP) e Manutenzione il formato sar� AAMMGG. 
	//     Il codice � valido fino alle 24 del giorno in cui e' stato creato.
	
	// Esempio di apertura CCS il giorno 20/6/2023 ore 11:
	int hwcode  = 3457673287;
	int utcdate = 23062011;
	int action  = 1;
	
	int seed = hwcode + utcdate + action;
	
    srand(seed);

    printf("\n Pseudo-Random sequence:\n\n");
    PrngSequence(10);
	// Se il PRNG coincide con un numero della sequenza, allora il dispositivo apre.
	
	// Per generare maggior entropia, si potrebbe decidere di confrontare il PRNG con l'elemento n della sequenza,
	// dove n potrebbe essere il giorno della settimana (dayOfWeek),se possibile.
}

